package rs.edu.kpu.prijavaDogadjajaKPU2019;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrijavaDogadjajaKpu2019ApplicationTests {

	@Test
	void contextLoads() {
	}

}
